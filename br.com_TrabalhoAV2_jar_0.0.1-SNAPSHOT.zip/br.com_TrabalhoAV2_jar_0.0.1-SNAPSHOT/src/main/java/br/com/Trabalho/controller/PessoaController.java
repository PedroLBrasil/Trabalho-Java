/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.Trabalho.controller;

import br.com.Trabalho.model.Pessoa;
import br.com.Trabalho.repository.PessoaRepository;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
/**
 *
 * @author Meu Computador
 */
@Controller
public class PessoaController {

    @Autowired
    private PessoaRepository pessoaRepository;

    @GetMapping("/gerenciarPessoas")
    public String listarPessoas(Model model) {
        model.addAttribute("listaPessoas", pessoaRepository.findAll());
        return "gerenciar_pessoas";
    }

    @GetMapping("/novaPessoa")
    public String novaPessoa(Model model) {
        model.addAttribute("pessoa", new Pessoa());
        return "editar_pessoa";
    }

    @GetMapping("/editarPessoa/{id}")
    public String editarPessoa(@PathVariable("id") long idPessoa, Model model) {
        Optional<Pessoa> pessoa = pessoaRepository.findById(idPessoa);
        model.addAttribute("pessoa", pessoa.get());
        return "editar_pessoa";
    }

    @PostMapping("/salvarPessoa")
    public String salvarPessoa(Pessoa pessoa, BindingResult result) {
        if (result.hasErrors()) {
            return "editar_pessoa";
        }
        pessoaRepository.save(pessoa);
        return "redirect:/gerenciarPessoas";
    }

    @GetMapping("/excluirPessoa/{id}")
    public String excluirPessoa(@PathVariable("id") long idPessoa) {
        pessoaRepository.deleteById(idPessoa);
        return "redirect:/gerenciarPessoas";
    }
}

